# Accept parameters or fallback to environment variables
param(
  [string]$PatchId,
  [string]$Engine,
  [string]$Scope,
  [string]$Caching
)

# Use parameter if provided, otherwise fallback to environment variable
if (-not $PatchId) { $PatchId = [string]$env:patch_id }
if (-not $Engine)  { $Engine  = [string]$env:engine }
if (-not $Scope)   { $Scope   = [string]$env:scope }
if (-not $Caching) { $Caching = [string]$env:caching }

# Validate required arguments
if (-not $PatchId) { Write-Error 'PatchId is required.'; exit 2 }
if (-not $Engine)  { Write-Error 'Engine is required.'; exit 2 }
if (-not $Scope)   { Write-Error 'Scope is required.'; exit 2 }
#----------------------------------------------------

#NINJAWPM Scan error code
$errorNinja_scan = "0x80240001"
#----------------------------------------------------

#NINJAWPM Apply error code (for patch install and download)
$errorNinja_patch_install = "0x80070BC9"
$errorNinja_patch_download = "0x800700B7"
#----------------------------------------------------

#NINJAWPM Apply error code (for apply job)
$errorNinja_apply = "0x80242006"

#----------------------------------------------------

# Create .fail directory, if needed.
$fail_path = "C:\ProgramData\NinjaRMMAgent\NinjaWPM\.fail\"
if (!(Test-Path -Path $fail_path)) {
   New-Item -ItemType Directory -Path $fail_path
}
#----------------------------------------------------

#Exit code if file already exist
if (Test-Path -Path "${fail_path}${PatchId}.*") {
   Write-Output "A .fail file with that Patch ID already exists!"
     exit 1
} elseif (Test-Path -Path "${fail_path}scan.*") {
   Write-Output "A scan.fail file already exists!"
     exit 1
} elseif (Test-Path -Path "${fail_path}install.*") {
   Write-Output "A install.fail file already exists!"
     exit 1
}
#----------------------------------------------------

if ($Engine -match "OPSWAT|WINGET|CATALOG") {
  #Create fail file using patch ID for OPSWAT or WINGET
  $file_path = "${fail_path}" + "${PatchId}.apply.fail"
   #For OPSWAT
  if ($Engine -eq "OPSWAT") {
     #Add the code inside the file
      if ($ENV:PROCESSOR_ARCHITECTURE -eq "x86") {
        $url = "https://patching-data-files-dev.s3.us-east-1.amazonaws.com/testing/installers/win32/opswat.apply.fail"
      } else {
        $url = "https://patching-data-files-dev.s3.us-east-1.amazonaws.com/testing/installers/win64/opswat.apply.fail"
      }
     # Download/Add the fail file, if needed.
      if (!(Test-Path -Path $file_path)) {
        $wc = New-Object net.webclient
        $wc.Downloadfile($url, $file_path)
      }
   #For WINGET
  } elseif ($Engine -eq "WINGET") {
     #Add the code inside the file
      if ($ENV:PROCESSOR_ARCHITECTURE -eq "x86") {
        $url = "https://patching-data-files-dev.s3.us-east-1.amazonaws.com/testing/installers/win32/winget.apply.fail"
      } else {
        $url = "https://patching-data-files-dev.s3.us-east-1.amazonaws.com/testing/installers/win64/winget.apply.fail"
      }
     # Download/Add the fail file, if needed.
      if (!(Test-Path -Path $file_path)) {
        $wc = New-Object net.webclient
        $wc.Downloadfile($url, $file_path)
      }
  } else {
     #Add the code inside the file
      if ($ENV:PROCESSOR_ARCHITECTURE -eq "x86") {
        $url = "https://patching-data-files-dev.s3.us-east-1.amazonaws.com/testing/installers/win32/catalog.apply.fail"
      } else {
        $url = "https://patching-data-files-dev.s3.us-east-1.amazonaws.com/testing/installers/win64/catalog.apply.fail"
      }
     # Download/Add the fail file, if needed.
      if (!(Test-Path -Path $file_path)) {
        $wc = New-Object net.webclient
        $wc.Downloadfile($url, $file_path)
      }
   }
#----------------------------------------------------
  
} elseif (($Engine -match "NINJA OS") -and ($Scope -like "Apply")) {
  #Create fail file using patch ID for NINJAWPM OS and 3PP (Apply)
  $file_path = "${fail_path}" + "install.fail" 
   #Add the code inside the file
  Set-Content -Path $file_path -Value $errorNinja_apply -Encoding ASCII -NoNewline
#----------------------------------------------------
  
} elseif (($Engine -match "NINJA OS|NINJA 3PP") -and ($Scope -like "Patch Install")) {
   #Create fail file using patch ID for NINJAWPM OS and 3PP (Apply)
   if ($Engine -like "NINJA OS") {
     $file_path = "${fail_path}" + "${PatchId}.install.fail" 
     #Add the code inside the file
    Set-Content -Path $file_path -Value $errorNinja_patch_install -Encoding ASCII -NoNewline
   } else {
     $file_path = "${fail_path}" + "${PatchId}.apply.fail" 
     #Add the code inside the file
    Set-Content -Path $file_path -Value $errorNinja_patch_install -Encoding ASCII -NoNewline
   }
#----------------------------------------------------

} elseif (($Engine -like "NINJA OS") -and ($Scope -like "Scan")) {
   Write-Output "NINJA SCAN fail file being generated"
   #Create fail file using patch ID for NINJAWPM OS and 3PP (Scan)
   $file_path = "${fail_path}" + "scan.fail"
   #Add the code inside the file
  Set-Content -Path $file_path -Value $errorNinja_scan -Encoding ASCII -NoNewline
#----------------------------------------------------

} elseif (($Engine -match "NINJA OS|NINJA 3PP") -and ($Scope -like "Patch Download") -and ($Caching -like "Yes")) {
  #Create fail file using patch ID for NINJAWPM OS and 3PP (Apply)
  $file_path = "${fail_path}" + "${PatchId}.download.fail" 
  $file_path_caching = "${fail_path}" + "${PatchId}.download.cache.fail"
  $file_path_catalog = "${fail_path}" + "${PatchId}.download.catalog.fail"
  #Add the code inside the file
  Set-Content -Path $file_path -Value $errorNinja_patch_download -Encoding ASCII -NoNewline
  Set-Content -Path $file_path_caching -Value $errorNinja_patch_download -Encoding ASCII -NoNewline
  Set-Content -Path $file_path_catalog -Value $errorNinja_patch_download -Encoding ASCII -NoNewline
#----------------------------------------------------

} elseif (($Engine -like "NINJA OS|NINJA 3PP") -and ($Scope -like "Patch Download")) {
  #Create fail file using patch ID for NINJAWPM OS and 3PP (Apply)
  $file_path = "${fail_path}" + "${PatchId}.download.fail" 
  $file_path_catalog = "${fail_path}" + "${PatchId}.download.catalog.fail"
  #Add the code inside the file
  Set-Content -Path $file_path -Value $errorNinja_patch_download -Encoding ASCII -NoNewline
  Set-Content -Path $file_path_catalog -Value $errorNinja_patch_download -Encoding ASCII -NoNewline
#----------------------------------------------------

}

Get-ChildItem -Path $fail_path -Filter *.txt | ForEach-Object {
    $content = Get-Content $_.FullName | Where-Object { $_ -ne "" }
    Set-Content -Path $_.FullName -Value $content
}

